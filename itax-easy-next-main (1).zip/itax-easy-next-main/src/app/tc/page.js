import Tnc from "@/app_old/pages/Tnc";

const index = () => {
  return <Tnc />;
};

export default index;
