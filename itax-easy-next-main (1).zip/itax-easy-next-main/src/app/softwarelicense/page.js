import Softwarelicence from "@/app_old/pages/Softwarelicense";

const index = () => {
  return <Softwarelicence />;
};

export default index;
