import Cart from "@/components/pagesComponents/cart/Cart";

export default function index() {
    return (
        <Cart/>
    );
}