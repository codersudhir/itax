import RegisterStartup from "@/components/pagesComponents/registerStartup/RegisterStartup"
export default function index() {
  return (
    <RegisterStartup/>
  )
}
