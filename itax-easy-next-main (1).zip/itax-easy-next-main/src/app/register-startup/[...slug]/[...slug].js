import ServicesPage from "@/app_old/pages/SevicesPage";

const index = () => {
  return <ServicesPage />;
};

export default index;
