import DirectorDetails from "@/app_old/pages/EasyServices/MCA/DirectorDetails";

const index = () => {
  return <DirectorDetails />;
};

export default index;
