import IfscDetails from "@/app_old/pages/EasyServices/BankLinks/IfscDetails";

const index = () => {
  return <IfscDetails />;
};

export default index;
