import VerifyBankDetails from "@/app_old/pages/EasyServices/BankLinks/VerifyBankDetails";

const index = () => {
  return <VerifyBankDetails />;
};

export default index;
