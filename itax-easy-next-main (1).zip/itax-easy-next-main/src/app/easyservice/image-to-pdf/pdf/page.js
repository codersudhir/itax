import PdfViewer from "@/app_old/pages/EasyServices/Converter/ImagePdf";
export default function page() {
    return (
        <PdfViewer/>
    );
}