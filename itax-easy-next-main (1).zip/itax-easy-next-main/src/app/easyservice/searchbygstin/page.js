import Searchbygstin from "@/app_old/pages/EasyServices/GstLinks/Searchbygstin";

const index = () => {
  return <Searchbygstin />;
};

export default index;
