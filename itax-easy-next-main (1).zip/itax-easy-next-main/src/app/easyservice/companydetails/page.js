import CompanyDetails from "@/app_old/pages/EasyServices/MCA/CompanyDetails";

const index = () => {
  return <CompanyDetails />;
};

export default index;
