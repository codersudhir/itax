import Trackgstreturn from "@/app_old/pages/EasyServices/GstLinks/Trackgstreturn";

const index = () => {
  return <Trackgstreturn />;
};

export default index;
