import VerifyPanDetails from "@/app_old/pages/EasyServices/IncomeTaxLinks/VerifyPanDetails";

const index = () => {
  return <VerifyPanDetails />;
};

export default index;
