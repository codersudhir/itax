import Apis from "@/app_old/pages/Apis";

const index = () => {
  return <Apis />;
};

export default index;
