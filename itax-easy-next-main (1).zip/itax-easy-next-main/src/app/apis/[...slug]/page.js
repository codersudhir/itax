import ApiDocs from "@/app_old/pages/ApiDocs";

const index = ({ params }) => {
  return <ApiDocs params={params} />;
};

export default index;
