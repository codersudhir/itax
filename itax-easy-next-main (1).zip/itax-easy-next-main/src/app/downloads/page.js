import DownloadIndex from "@/app_old/pages/Downloads/DownloadIndex";

const index = () => {
  return <DownloadIndex />;
};

export default index;
