import Form16 from "@/app_old/pages/Downloads/Form16";

const index = () => {
  return (
    <div className="transition-all duration-100 lg:container 2xl:max-w-7xl mx-auto mb-12">
      <Form16 />
    </div>
  );
};

export default index;
