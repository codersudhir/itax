import Depreciationtable from "@/app_old/pages/Downloads/Depreciationtable";

const index = () => {
  return (
    <div className="transition-all duration-100 lg:container 2xl:max-w-7xl mx-auto mb-12">
      <Depreciationtable />
    </div>
  );
};

export default index;
