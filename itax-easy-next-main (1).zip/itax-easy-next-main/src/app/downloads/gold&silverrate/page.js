import Goldsilverrate from "@/app_old/pages/Downloads/Goldsilverrate";

const index = () => {
  return (
    <div className="transition-all duration-100 lg:container 2xl:max-w-7xl mx-auto mb-12">
      <Goldsilverrate />
    </div>
  );
};

export default index;
