import Statuswiseincometaxcodepan from "@/app_old/pages/Downloads/Statuswiseincometaxcodepan";

const index = () => {
  return (
    <div className="transition-all duration-100 lg:container 2xl:max-w-7xl mx-auto mb-12">
      <Statuswiseincometaxcodepan />
    </div>
  );
};

export default index;
