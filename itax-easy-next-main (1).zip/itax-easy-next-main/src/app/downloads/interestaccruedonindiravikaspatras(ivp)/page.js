import InterestaccruedonIndira from "@/app_old/pages/Downloads/InterestaccruedonIndira";

const index = () => {
  return (
    <div className="transition-all duration-100 lg:container 2xl:max-w-7xl mx-auto mb-12">
      <InterestaccruedonIndira />
    </div>
  );
};

export default index;
