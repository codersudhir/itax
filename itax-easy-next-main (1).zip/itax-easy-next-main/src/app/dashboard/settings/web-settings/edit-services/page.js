import Edit_Services from "@/components/pagesComponents/dashboard/settings/webSettings/edit/Edit_Services"

export default function EditServices() {
    return (
        <Edit_Services />
    )
}
