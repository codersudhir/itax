import Edit_HomePage from "@/components/pagesComponents/dashboard/settings/webSettings/edit/Edit_HomePage"

export default function EditHomePage() {
    return (
        <Edit_HomePage />
    )
}
