import Edit_Footer from "@/components/pagesComponents/dashboard/settings/webSettings/edit/Edit_Footer"

export default function EditServices() {
    return (
        <Edit_Footer />
    )
}
