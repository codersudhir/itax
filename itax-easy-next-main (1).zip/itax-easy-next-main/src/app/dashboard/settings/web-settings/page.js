import WebSettings_Dashboard from "@/components/pagesComponents/dashboard/settings/webSettings/WebSettings_Dashboard"
export default function WebSettings() {
    return (
        <WebSettings_Dashboard/>
    )
}
