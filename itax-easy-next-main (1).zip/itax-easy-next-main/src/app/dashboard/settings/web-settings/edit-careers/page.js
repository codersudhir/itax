import Edit_Careers from "@/components/pagesComponents/dashboard/settings/webSettings/edit/Edit_Careers"

export default function EditCareers() {
    return (
        <Edit_Careers />
    )
}
