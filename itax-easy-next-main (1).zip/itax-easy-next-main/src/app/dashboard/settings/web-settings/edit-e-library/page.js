import Edit_ELibrary from "@/components/pagesComponents/dashboard/settings/webSettings/edit/Edit_ELibrary"

export default function EditELibrary() {
    return (
        <Edit_ELibrary />
    )
}
