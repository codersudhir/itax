import Edit_Startups from "@/components/pagesComponents/dashboard/settings/webSettings/edit/Edit_Startups";

const page = () => {
  return <Edit_Startups />;
};

export default page;
