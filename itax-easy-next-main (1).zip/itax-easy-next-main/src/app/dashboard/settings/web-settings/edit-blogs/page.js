import Edit_Blogs from "@/components/pagesComponents/dashboard/settings/webSettings/edit/Edit_Blogs"

export default function EditBlogs() {
    return (
        <Edit_Blogs />
    )
}
