import Settings_Dashboard from "@/components/pagesComponents/dashboard/settings/Settings"
export default function Settings() {
    return (
        <Settings_Dashboard/>
    )
}
