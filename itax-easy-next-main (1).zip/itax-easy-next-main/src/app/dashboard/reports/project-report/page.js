import Project_Report from "@/components/pagesComponents/dashboard/Project_Report/Project_Report"
export default function projectReport() {
    return (
        <Project_Report/>
    )
}
