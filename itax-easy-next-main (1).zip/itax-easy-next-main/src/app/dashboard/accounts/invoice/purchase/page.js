import Purchase from "@/components/pagesComponents/dashboard/accounts/invoice/purchase/Purchase";
export default function page() {
    return (
        <Purchase />
    );
}