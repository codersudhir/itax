import ReturnSales from "@/components/pagesComponents/dashboard/accounts/invoice/sales/ReturnSales"
export default function Create() {
    return (
        <ReturnSales/>
    )
}
