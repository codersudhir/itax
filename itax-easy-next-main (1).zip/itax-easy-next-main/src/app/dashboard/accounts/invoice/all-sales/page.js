import AllSales from "@/components/pagesComponents/dashboard/accounts/invoice/sales/AllSales"

export default function Parties() {
    return (
        <AllSales/>
    )
}
