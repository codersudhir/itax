import CreateSale from "@/components/pagesComponents/dashboard/accounts/invoice/sales/CreateSales"
export default function Create() {
    return (
        <CreateSale/>
    )
}
