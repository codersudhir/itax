import AllInvoice from "@/components/pagesComponents/dashboard/accounts/invoice/invoice/AllInvoice"
export default function Invoice() {
    return (
        <AllInvoice/>
    )
}
