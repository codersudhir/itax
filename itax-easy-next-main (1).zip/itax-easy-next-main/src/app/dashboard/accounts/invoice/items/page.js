import Items from "@/components/pagesComponents/dashboard/accounts/invoice/items/Items";
export default function page() {
    return (
        <Items />
    );
}