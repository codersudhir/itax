import CreateItem from "@/components/pagesComponents/dashboard/accounts/invoice/items/CreateItem"
export default function Create() {
    return (
        <CreateItem/>
    )
}
