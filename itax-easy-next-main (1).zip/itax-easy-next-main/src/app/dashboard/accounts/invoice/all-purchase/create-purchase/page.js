import CreateParty from "@/components/pagesComponents/dashboard/accounts/invoice/parties/CreateParty"
export default function Create() {
    return (
        <CreateParty/>
    )
}
