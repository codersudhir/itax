import AllPurchase from "@/components/pagesComponents/dashboard/accounts/invoice/purchase/AllPurchase"

export default function Parties() {
    return (
        <AllPurchase/>
    )
}
