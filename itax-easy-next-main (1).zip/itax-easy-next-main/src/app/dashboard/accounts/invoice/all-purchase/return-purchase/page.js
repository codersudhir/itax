import ReturnPurchase from "@/components/pagesComponents/dashboard/accounts/invoice/purchase/ReturnPurchase"
export default function Create() {
    return (
        <ReturnPurchase/>
    )
}
