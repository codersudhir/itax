import Sales from "@/components/pagesComponents/dashboard/accounts/invoice/sales/Sales";

export default function page() {
    return (
        <Sales/>
    );
}