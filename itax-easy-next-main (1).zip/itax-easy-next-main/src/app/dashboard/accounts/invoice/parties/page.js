import AllParties from "@/components/pagesComponents/dashboard/accounts/invoice/parties/AllParties"

export default function Parties() {
    return (
        <AllParties/>
    )
}
