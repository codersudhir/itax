import InvoiceDashboard_Index from "@/components/pagesComponents/dashboard/accounts/invoice/InvoiceDashboard_index";
export default function page() {
    return (
        <InvoiceDashboard_Index/>
    );
}