import BillPayment_Dashboard from "@/components/pagesComponents/dashboard/superAdmin/billPayment/BillPayment_Dashboard"
export default function BillPayment() {
  return (
    <BillPayment_Dashboard/>
  )
}
