import BusinessProfile from "@/components/pagesComponents/dashboard/businessProfile/BusinessProfile"

export default function index() {
    return (
        <BusinessProfile/>
    )
}
