
export default function user() {
    return (
        <h1>user profile</h1>
    )
}
