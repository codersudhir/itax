import Allusers from "@/components/pagesComponents/dashboard/superAdmin/all_users/Allusers";
import React from "react";

const page = () => {
  return <Allusers />;
};

export default page;
