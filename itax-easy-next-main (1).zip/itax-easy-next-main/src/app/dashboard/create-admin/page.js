import Create_admin from "@/components/pagesComponents/dashboard/superAdmin/all_admin/Create_admin"


const page = () => {
  return (
   <Create_admin/>
  )
}

export default page