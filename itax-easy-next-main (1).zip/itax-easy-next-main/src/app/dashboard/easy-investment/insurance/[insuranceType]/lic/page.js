import LIC_Dashboard from "@/components/pagesComponents/dashboard/easyInvestment/insurance/selectInsurance/LIC/LIC_dashboard.js";
export default function insurance() {
    return <LIC_Dashboard/>;
}
