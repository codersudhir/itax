export default function starHealth() {
    return (
        <div>
            <h1>Star Health</h1>
        </div>
    );
}