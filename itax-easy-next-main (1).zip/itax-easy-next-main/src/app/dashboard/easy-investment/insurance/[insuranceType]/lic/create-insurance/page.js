import HealthSteps from "@/components/pagesComponents/dashboard/easyInvestment/insurance/selectInsurance/LIC/health/HealthSteps";
export default function page() {
    return (
        <HealthSteps/>
    );
}