import ViewPlans from "@/components/pagesComponents/dashboard/easyInvestment/insurance/selectInsurance/LIC/health/plans/ViewPlans";
export default function page() {
    return (
       <ViewPlans/>
    );
}