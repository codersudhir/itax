import SelectInsuranceType from "@/components/pagesComponents/dashboard/easyInvestment/insurance/InsuranseType"
export default function insurance() {
    return (
        <SelectInsuranceType/>
    )
}
