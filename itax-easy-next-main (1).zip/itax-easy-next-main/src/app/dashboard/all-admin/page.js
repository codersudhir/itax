import Alladmin from "@/components/pagesComponents/dashboard/superAdmin/all_admin/Alladmin"


const page = () => {
  return (
   <Alladmin/>
  )
}

export default page