import Payment_index from "@/components/pagesComponents/dashboard/Finance/Payment/Payment_index"
export default function loan() {
    return (
        <Payment_index/>
    )
}
