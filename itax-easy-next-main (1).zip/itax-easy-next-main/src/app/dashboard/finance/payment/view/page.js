import View_Payment from "@/components/pagesComponents/dashboard/Finance/Payment/View_Payment"
export default function View() {
    return (
        <View_Payment/>
    )
}
