import Loan_Index from "@/components/pagesComponents/dashboard/Finance/Loan/Loan_Index"
export default function loan() {
    return (
        <Loan_Index/>
    )
}
