import Apply_Loan from "@/components/pagesComponents/dashboard/Finance/Loan/Apply_Loan"
export default function Apply() {
    return (
        <Apply_Loan/>
    )
}
