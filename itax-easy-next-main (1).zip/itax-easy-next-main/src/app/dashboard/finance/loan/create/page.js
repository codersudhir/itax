import Create_Loan from "@/components/pagesComponents/dashboard/Finance/Loan/Create_Loan"
export default function Create() {
    return (
        <Create_Loan/>
    )
}
