import Agents from '@/components/pagesComponents/dashboard/admin/Network/Agents'
import React from 'react'

const page = () => {
  return (
    <Agents/>
  )
}

export default page