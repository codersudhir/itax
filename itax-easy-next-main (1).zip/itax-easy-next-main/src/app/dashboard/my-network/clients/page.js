import Clients from '@/components/pagesComponents/dashboard/admin/Network/Clients'
import React from 'react'

const page = () => {
  return (
   <Clients/>
  )
}

export default page