import Create_Agents from "@/components/pagesComponents/dashboard/admin/Network/Create_Agents"


const page = () => {
  return (
   <Create_Agents/>
  )
}

export default page