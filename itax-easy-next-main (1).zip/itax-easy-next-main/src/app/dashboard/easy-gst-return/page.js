import GSTR from "@/components/pagesComponents/dashboard/GSTR/GSTR";
export default function EasyGSTReturn() {
	return (
		<GSTR/>
	);
}

