import TrackGstReturn from "@/components/pagesComponents/dashboard/GSTR/GSTRPages/trackGstReturn/TrackGstReturn";
export default function checkReturnStatus() {
    return (
        <TrackGstReturn/>
    );
}