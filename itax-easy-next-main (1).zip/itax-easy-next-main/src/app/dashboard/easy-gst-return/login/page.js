import LoginWithGstin from "@/components/pagesComponents/dashboard/GSTR/GSTRPages/loginWithGstin/LoginWithGstin";

export default function index() {
    return (
        <LoginWithGstin />
    );
}