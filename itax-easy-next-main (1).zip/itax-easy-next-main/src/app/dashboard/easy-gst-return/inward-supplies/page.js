import InwardSupplies from "@/components/pagesComponents/dashboard/GSTR/GSTRPages/InwardSupplies/InwardSupplies"
export default function inwardSupplies() {
    return (
        <InwardSupplies/>
    )
}
