import Six_A_Export from "@/components/pagesComponents/dashboard/GSTR/GSTRPages/Gstr1/Add_Record_Details/Six_A_Export";
export default function page() {
    return (
        <Six_A_Export />
    );
}