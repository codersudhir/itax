import Elevin_Bone_btwo from "@/components/pagesComponents/dashboard/GSTR/GSTRPages/Gstr1/Add_Record_Details/Elevin_Bone_btwo";

const page = () => {
  return <Elevin_Bone_btwo />;
};

export default page;
