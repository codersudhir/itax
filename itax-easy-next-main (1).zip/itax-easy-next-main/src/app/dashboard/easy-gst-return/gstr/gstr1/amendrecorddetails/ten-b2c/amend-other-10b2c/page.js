import Ten_b2c_From from "@/components/pagesComponents/dashboard/GSTR/GSTRPages/Gstr1/Amend_Reccord_Details/Amend_Form/Ten_b2c_From";

const page = () => {
  return <Ten_b2c_From />;
};

export default page;
