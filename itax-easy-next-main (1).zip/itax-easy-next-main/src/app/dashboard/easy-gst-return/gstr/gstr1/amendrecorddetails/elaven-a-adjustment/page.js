import Elaven_A_Adjustment from "@/components/pagesComponents/dashboard/GSTR/GSTRPages/Gstr1/Amend_Reccord_Details/Elaven_A_Adjustment";

const page = () => {
  return <Elaven_A_Adjustment />;
};

export default page;
