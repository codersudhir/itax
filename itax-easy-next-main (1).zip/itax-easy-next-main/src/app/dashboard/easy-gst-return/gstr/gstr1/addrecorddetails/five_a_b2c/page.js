import Five_A_B2C from "@/components/pagesComponents/dashboard/GSTR/GSTRPages/Gstr1/Add_Record_Details/Five_A_B2C";

const index = () => {
  return <Five_A_B2C />;
};

export default index;
