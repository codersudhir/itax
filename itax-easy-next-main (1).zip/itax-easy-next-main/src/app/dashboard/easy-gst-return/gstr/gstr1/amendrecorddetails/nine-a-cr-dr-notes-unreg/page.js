import Nine_A_Credit_Debit_Notes_Un from "@/components/pagesComponents/dashboard/GSTR/GSTRPages/Gstr1/Amend_Reccord_Details/Nine_A_Credit_Debit_Notes_Un";

const page = () => {
  return <Nine_A_Credit_Debit_Notes_Un />;
};

export default page;
