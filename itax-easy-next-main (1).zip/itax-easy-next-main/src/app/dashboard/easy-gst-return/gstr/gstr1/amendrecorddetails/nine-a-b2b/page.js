import Nine_A_b2b from "@/components/pagesComponents/dashboard/GSTR/GSTRPages/Gstr1/Amend_Reccord_Details/Nine_A_b2b";

const page = () => {
  return <Nine_A_b2b />;
};

export default page;
