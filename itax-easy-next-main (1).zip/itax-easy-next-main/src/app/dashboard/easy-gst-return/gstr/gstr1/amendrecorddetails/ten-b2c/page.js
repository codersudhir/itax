import Ten_b2c from "@/components/pagesComponents/dashboard/GSTR/GSTRPages/Gstr1/Amend_Reccord_Details/Ten_b2c";

const page = () => {
  return <Ten_b2c />;
};

export default page;
