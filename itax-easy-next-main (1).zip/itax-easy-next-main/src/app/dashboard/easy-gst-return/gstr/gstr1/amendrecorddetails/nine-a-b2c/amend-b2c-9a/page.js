import Nine_A_b2c_From from "@/components/pagesComponents/dashboard/GSTR/GSTRPages/Gstr1/Amend_Reccord_Details/Amend_Form/Nine_A_b2c_From";

const page = () => {
  return <Nine_A_b2c_From />;
};

export default page;
