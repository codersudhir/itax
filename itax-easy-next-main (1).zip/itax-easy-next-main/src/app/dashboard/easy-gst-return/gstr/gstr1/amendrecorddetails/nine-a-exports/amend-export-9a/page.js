import Nine_A_Export_From from "@/components/pagesComponents/dashboard/GSTR/GSTRPages/Gstr1/Amend_Reccord_Details/Amend_Form/Nine_A_Export_From";

const page = () => {
  return <Nine_A_Export_From />;
};

export default page;
