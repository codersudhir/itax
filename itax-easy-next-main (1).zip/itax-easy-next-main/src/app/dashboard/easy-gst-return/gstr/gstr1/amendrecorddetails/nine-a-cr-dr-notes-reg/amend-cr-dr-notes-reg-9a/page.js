import Nine_A_Credit_Debit_Notes_From from "@/components/pagesComponents/dashboard/GSTR/GSTRPages/Gstr1/Amend_Reccord_Details/Amend_Form/Nine_A_Credit_Debit_Notes_From";
import React from "react";

const page = () => {
  return <Nine_A_Credit_Debit_Notes_From />;
};

export default page;
