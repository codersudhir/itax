import Nine_A_b2c from "@/components/pagesComponents/dashboard/GSTR/GSTRPages/Gstr1/Amend_Reccord_Details/Nine_A_b2c";

const page = () => {
  return <Nine_A_b2c />;
};

export default page;
