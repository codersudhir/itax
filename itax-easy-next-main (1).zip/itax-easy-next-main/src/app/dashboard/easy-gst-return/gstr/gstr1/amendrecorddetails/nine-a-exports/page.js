import Nine_A_Export from "@/components/pagesComponents/dashboard/GSTR/GSTRPages/Gstr1/Amend_Reccord_Details/Nine_A_Export";

const page = () => {
  return <Nine_A_Export />;
};

export default page;
