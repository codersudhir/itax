import NineB_Credit_Debit_NotesUN from "@/components/pagesComponents/dashboard/GSTR/GSTRPages/Gstr1/Add_Record_Details/NineB_Credit_Debit_NotesUN";

const index = () => {
  return <NineB_Credit_Debit_NotesUN />;
};

export default index;
