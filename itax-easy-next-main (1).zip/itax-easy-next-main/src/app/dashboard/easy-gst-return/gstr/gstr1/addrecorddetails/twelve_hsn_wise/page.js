import Twelve_HSN_Wise from "@/components/pagesComponents/dashboard/GSTR/GSTRPages/Gstr1/Add_Record_Details/Twelve_HSN_Wise";

const page = () => {
  return <Twelve_HSN_Wise />;
};

export default page;
