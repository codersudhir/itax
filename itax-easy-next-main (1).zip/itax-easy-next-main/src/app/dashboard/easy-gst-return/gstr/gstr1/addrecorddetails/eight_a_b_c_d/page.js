import Eight_A_B_C_D from "@/components/pagesComponents/dashboard/GSTR/GSTRPages/Gstr1/Add_Record_Details/Eight_A_B_C_D";

const index = () => {
  return <Eight_A_B_C_D />;
};

export default index;
