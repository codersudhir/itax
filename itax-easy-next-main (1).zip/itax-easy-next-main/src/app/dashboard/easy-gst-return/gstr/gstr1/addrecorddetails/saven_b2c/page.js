import Saven_B2C from "@/components/pagesComponents/dashboard/GSTR/GSTRPages/Gstr1/Add_Record_Details/Saven_B2C";

const index = () => {
  return <Saven_B2C />;
};

export default index;
