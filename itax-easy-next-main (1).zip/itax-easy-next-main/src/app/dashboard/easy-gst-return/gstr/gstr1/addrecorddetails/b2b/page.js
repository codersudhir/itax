import B2B from "@/components/pagesComponents/dashboard/GSTR/GSTRPages/Gstr1/Add_Record_Details/B2B";

const index = () => {
  return <B2B />;
};

export default index;
