import Nine_A_b2b_Form from "@/components/pagesComponents/dashboard/GSTR/GSTRPages/Gstr1/Amend_Reccord_Details/Amend_Form/Nine_A_b2b_Form";

const page = () => {
  return <Nine_A_b2b_Form />;
};

export default page;
