import NineB_Credit_Debit_Notes from "@/components/pagesComponents/dashboard/GSTR/GSTRPages/Gstr1/Add_Record_Details/NineB_Credit_Debit_Notes";

const Index = () => {
  return <NineB_Credit_Debit_Notes />;
};

export default Index;
