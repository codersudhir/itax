import Elaven_A_Tax_Liability_From from "@/components/pagesComponents/dashboard/GSTR/GSTRPages/Gstr1/Amend_Reccord_Details/Amend_Form/Elaven_A_Tax_Liability_From";

const page = () => {
  return <Elaven_A_Tax_Liability_From />;
};

export default page;
