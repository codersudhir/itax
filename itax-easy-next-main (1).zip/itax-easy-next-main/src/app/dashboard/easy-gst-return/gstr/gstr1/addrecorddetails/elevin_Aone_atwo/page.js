import Elevin_Aone_atwo from "@/components/pagesComponents/dashboard/GSTR/GSTRPages/Gstr1/Add_Record_Details/Elevin_Aone_atwo";

const page = () => {
  return <Elevin_Aone_atwo />;
};

export default page;
