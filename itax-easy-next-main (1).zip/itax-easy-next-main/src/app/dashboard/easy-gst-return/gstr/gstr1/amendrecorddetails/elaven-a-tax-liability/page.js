import Elaven_A_Tax_Liability from "@/components/pagesComponents/dashboard/GSTR/GSTRPages/Gstr1/Amend_Reccord_Details/Elaven_A_Tax_Liability";

const page = () => {
  return <Elaven_A_Tax_Liability />;
};

export default page;
