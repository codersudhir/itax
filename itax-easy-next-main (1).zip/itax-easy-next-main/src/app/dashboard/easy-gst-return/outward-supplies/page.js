import OutwardSupplies from "@/components/pagesComponents/dashboard/GSTR/GSTRPages/OutwardSupplies/OutwardSupplies"
export default function outwardSupplies () {
    return (
        <OutwardSupplies/>
    )
}
