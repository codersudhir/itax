import NotFound from "@/components/partials/notFound/NotFound";
export default function notFound() {
	return (
        <NotFound/>
	);
}
