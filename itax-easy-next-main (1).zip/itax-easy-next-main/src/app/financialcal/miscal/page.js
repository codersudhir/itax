import PostofficeCal from "@/app_old/pages/Financial Calculators/Investmentcal/PostofficeCal";

const index = () => {
  return <PostofficeCal />;
};

export default index;
