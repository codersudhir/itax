import SipCal from "@/app_old/pages/Financial Calculators/Investmentcal/SipCal";

const index = () => {
  return <SipCal />;
};

export default index;
