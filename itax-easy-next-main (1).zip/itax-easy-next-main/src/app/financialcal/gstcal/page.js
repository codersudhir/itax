import GstCal from "@/app_old/pages/Financial Calculators/GstCal/GstCal";

const index = () => {
  return <GstCal />;
};

export default index;
