import CompoundInterestCal from "@/app_old/pages/Financial Calculators/BankCalculators/CompoundInterestCal";

const index = () => {
  return <CompoundInterestCal />;
};

export default index;
