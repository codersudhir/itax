import FdCal from "@/app_old/pages/Financial Calculators/Investmentcal/FdCal";

const index = () => {
  return <FdCal />;
};

export default index;
