import HraCal from "@/app_old/pages/Financial Calculators/IncomeTaxCalculators/HraCal";

const index = () => {
  return <HraCal />;
};

export default index;
