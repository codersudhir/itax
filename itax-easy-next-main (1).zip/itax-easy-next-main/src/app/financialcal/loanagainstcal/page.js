import LoanAgainstProperty from "@/app_old/pages/Financial Calculators/LoanCalculators/LoanAgainstProperty";

const index = () => {
  return <LoanAgainstProperty />;
};

export default index;
