import LumpSumpCal from "@/app_old/pages/Financial Calculators/Investmentcal/LumpSumpCal";

const index = () => {
  return <LumpSumpCal />;
};

export default index;
