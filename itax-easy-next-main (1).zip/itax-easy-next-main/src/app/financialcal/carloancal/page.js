import CarloanCal from "@/app_old/pages/Financial Calculators/LoanCalculators/CarloanCal";

const index = () => {
  return <CarloanCal />;
};

export default index;
