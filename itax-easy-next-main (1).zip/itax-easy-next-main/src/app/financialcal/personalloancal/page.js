import PersonalCal from "@/app_old/pages/Financial Calculators/LoanCalculators/PersonalCal";

const index = () => {
  return <PersonalCal />;
};

export default index;
