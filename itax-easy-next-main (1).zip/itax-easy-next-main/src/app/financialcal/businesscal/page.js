import BusinessCal from "@/app_old/pages/Financial Calculators/LoanCalculators/BusinessCal";

const index = () => {
  return <BusinessCal />;
};

export default index;
