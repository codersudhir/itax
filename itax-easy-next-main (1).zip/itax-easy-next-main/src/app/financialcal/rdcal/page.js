import RdCal from "@/app_old/pages/Financial Calculators/Investmentcal/RdCal";

const index = () => {
  return <RdCal />;
};

export default index;
