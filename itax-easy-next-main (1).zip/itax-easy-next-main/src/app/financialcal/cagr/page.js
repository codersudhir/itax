import CAGR from "@/app_old/pages/Financial Calculators/Investmentcal/CAGR";

const index = () => {
  return <CAGR />;
};

export default index;
