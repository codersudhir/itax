import CapitalGainCal from "@/app_old/pages/Financial Calculators/IncomeTaxCalculators/CapitalGainCal";

const index = () => {
  return <CapitalGainCal />;
};

export default index;
