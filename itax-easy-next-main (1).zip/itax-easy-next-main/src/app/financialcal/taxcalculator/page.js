import TaxCalculator from "@/app_old/pages/Financial Calculators/IncomeTaxCalculators/taxCalculator/TaxCalculator";

const index = () => {
  return <TaxCalculator />;
};

export default index;
