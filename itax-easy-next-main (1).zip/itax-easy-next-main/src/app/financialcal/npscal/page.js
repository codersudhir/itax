import NpsCal from "@/app_old/pages/Financial Calculators/InsuranceCalculatos/NpsCal";

const index = () => {
  return <NpsCal />;
};

export default index;
