import AdvanceTaxCalc from "@/app_old/pages/Financial Calculators/IncomeTaxCalculators/advanceTaxCal/AdvanceTaxCal";

const index = () => {
  return <AdvanceTaxCalc />;
};

export default index;
