import SimpleInterestCal from "@/app_old/pages/Financial Calculators/BankCalculators/SimpleInterestCal";

const index = () => {
  return <SimpleInterestCal />;
};

export default index;
