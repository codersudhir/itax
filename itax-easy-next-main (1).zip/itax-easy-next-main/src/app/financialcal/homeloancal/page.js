import HomeloanCal from "@/app_old/pages/Financial Calculators/LoanCalculators/HomeLoanCal";

const index = () => {
  return <HomeloanCal />;
};

export default index;
