import DepreciationCal from "@/app_old/pages/Financial Calculators/IncomeTaxCalculators/DepreciationCal";

const index = () => {
  return <DepreciationCal />;
};

export default index;
