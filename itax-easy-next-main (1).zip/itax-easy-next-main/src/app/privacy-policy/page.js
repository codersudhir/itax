import PrivacyPolicy from "@/app_old/pages/PrivacyPolicy";
const index = () => {
  return <PrivacyPolicy />;
};

export default index;
