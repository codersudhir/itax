import ContactUs from "@/app_old/pages/Company/ContactUs";

const index = () => {
  return <ContactUs />;
};

export default index;
