import DisclaimerPolicy from "@/app_old/pages/DisclaimerPolicy";

const index = () => {
  return <DisclaimerPolicy />;
};

export default index;
