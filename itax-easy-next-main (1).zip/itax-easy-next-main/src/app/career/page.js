import Career from "@/app_old/pages/Career";

const index = () => {
  return <Career />;
};

export default index;
