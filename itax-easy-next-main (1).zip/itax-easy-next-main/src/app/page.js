import Home from "@/app_old/pages/Home";
export default function home() {
    return (
        <Home/>
    )
}
