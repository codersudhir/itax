import About from "@/app_old/pages/Company/About_page/About";
export default function page() {
    return (
        <About/>
    );
}