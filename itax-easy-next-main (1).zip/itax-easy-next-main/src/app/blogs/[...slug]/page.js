import BlogIndividualPage from "@/app_old/pages/Blogs/BlogIndividualPage";

const index = ({ params }) => {
  return (
    <div>
      <BlogIndividualPage params={params} />
    </div>
  );
};

export default index;
