import Blogs from "@/app_old/pages/Blogs/Blogs";

const index = () => {
  return (
    <div>
      <Blogs />
    </div>
  );
};

export default index;
