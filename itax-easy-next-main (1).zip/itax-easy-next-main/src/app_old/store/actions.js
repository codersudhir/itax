export const LOGIN = 'login';

export const LOGOUT = 'logout';

export const VERIFY_USER = 'verify-user';

export const SET_VERIFICATION_DETAILS = 'set-verification-details';

export const ITR = 'itr';

export const ITR_TYPE = 'itr-type';

export const FORM_16_IMPORT = 'form-16-import';

export const PDF_DOC="pdfDoc"

export const PDF_DOC1="pdfDoc1"

export const CART_DETAIL="cartDetail"

export const API_CART="apiCart"

export const LIB_PDF_DOC = "libraryPdfDoc";

export const IMG_PDF="imagePDF"


export const GSTIN="GSTIN"

export const BUSINESS_DETAILS="BusinessDetails"

export const PDF_DOC_REPORT="pdfDocReport"
export const IS_INVOICE_SIDEBAR_OPEN="isInvoiceSidebarOpen"
