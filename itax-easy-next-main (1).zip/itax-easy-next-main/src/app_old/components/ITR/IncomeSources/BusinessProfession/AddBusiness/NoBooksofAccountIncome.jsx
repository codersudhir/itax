import NatureofBusinessComp from './NatureofBusinessComp';

export default function NoBooksofAccountIncome({setSection}) {
    return (
        <div className="mx-auto max-w-4xl w-full">
            <NatureofBusinessComp setSection={setSection} />
        </div>
    );
}
