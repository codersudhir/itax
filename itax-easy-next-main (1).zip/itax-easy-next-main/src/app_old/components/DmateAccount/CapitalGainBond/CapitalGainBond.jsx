import React from 'react'
import FormComponent from '../FormComponent'

const CapitalGainBond = () => {
  return (
    <FormComponent title={"Capital Gain Bond"} />
  )
}

export default CapitalGainBond