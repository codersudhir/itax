import React from 'react'
import FormComponent from '../FormComponent'

const FixedPlans = () => {
  return (
    <FormComponent title={"Fixed Plans"} />
  )
}

export default FixedPlans