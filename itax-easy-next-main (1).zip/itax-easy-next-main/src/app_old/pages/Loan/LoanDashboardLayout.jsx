import LoanDashboard from "./components/LoanDashboard";

function LoanDashboad() {
  return (
    <div className='md:w-3/4 p-2 min-h-screen mx-auto'>
      <LoanDashboard />
    </div>
  );
}

export default LoanDashboad;