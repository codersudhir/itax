import React from 'react'
import Form16Component from '../../components/ITR/Form16/Form16Component'

const ITRForm16 = () => {
  return (
    <div>
      <Form16Component />
    </div>
  )
}

export default ITRForm16