"use client";
import { Icon } from "@iconify/react";

export function I(props) {
	return <Icon {...props} />;
}
export function InlineI(props) {
	return <Icon {...props} />;
}

